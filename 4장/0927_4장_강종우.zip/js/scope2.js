var hi = "hello";

function greeting(){
    console.log(hi);   //hi의 내용이 출력되나?
}

greeting();